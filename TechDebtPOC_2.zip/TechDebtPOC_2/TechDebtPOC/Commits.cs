﻿using System.Collections.Generic;

namespace TechDebtPOC
{
    public class Value
    {
        public string id { get; set; }
        public string displayId { get; set; }
        public Author author { get; set; }
        public object authorTimestamp { get; set; }
        public Committer committer { get; set; }
        public object committerTimestamp { get; set; }
        public string message { get; set; }
        public List<Parent> parents { get; set; }
        public Properties properties { get; set; }
    }

    public class Commits
    {
        public List<Value> values { get; set; }
        public int size { get; set; }
        public bool isLastPage { get; set; }
        public int start { get; set; }
        public int limit { get; set; }
        public int nextPageStart { get; set; }
    }
}