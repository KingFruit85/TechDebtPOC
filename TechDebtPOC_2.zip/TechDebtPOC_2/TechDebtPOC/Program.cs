﻿using System.Configuration;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using static TechDebtPOC.BitbucketRequestor;

namespace TechDebtPOC
{
    // Bitbucket API docs
    // https://developer.atlassian.com/cloud/bitbucket/rest/intro/#filtering
    // https://developer.atlassian.com/cloud/bitbucket/rest/api-group-commits/#api-repositories-workspace-repo-slug-commits-post

    class Program
    {
        static async Task Main(string[] args)
        {
            // Create an HttpClientHandler object and set to use the credentials stored in app.config
            // Doing it in this funcy way to avoid displaying my creds when screensharing
            string base64EncodedAuthenticationString = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{ConfigurationManager.AppSettings["username"]}:{ConfigurationManager.AppSettings["password"]}"));
            BitbucketRequestor.httpClient.DefaultRequestHeaders.Add($"Authorization", $"Basic {base64EncodedAuthenticationString}");

            // Base address is where you set the root/base address, it's important to make sure the trailing forward slash / is included
            BitbucketRequestor.httpClient.BaseAddress = new Uri("https://stash.aviva.co.uk/rest/api/latest/projects/unisure/repos/application/");
            BitbucketRequestor.httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


            // Get the commits for a given timeframe
            // TODO: pass in an int that sets the commit date cutoff date ie 1 = 1 year
            Dictionary<string, CommitDetails> commitIds = await BitbucketRequestor.GetCommitsAsync();

            // Create a dict that stores file names and the number of commits that have been made to them
            List<Tuple<string, string, DateTime>> allCommitsWithCommitDates = await BitbucketRequestor.GetFileChangesAsync( commitIds );

            // Save the output
            var outputFile = @"c:\temp\techDebtOutput.txt";
            File.AppendAllText(outputFile, "CommitID, FileName, CommitDate" + Environment.NewLine);

            foreach (var commit in allCommitsWithCommitDates)
            {
                File.AppendAllText(outputFile, $"{commit.Item1}, {commit.Item2}, {commit.Item3}" + Environment.NewLine);
            }
        }
    }
}