﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace TechDebtPOC
{
    public static class BitbucketRequestor
    {
        public static HttpClient httpClient = new HttpClient();
        public static Dictionary<string, CommitDetails> commitIds = new Dictionary<string, CommitDetails>();
        public static Dictionary<string, FileDetails> countOfTimesFileChanged = new Dictionary<string, FileDetails>();
        public static List<Tuple<string, string, DateTime>> allCommitData = new List<Tuple<string, string, DateTime>>();
        public static HttpResponseMessage response;

        public struct CommitDetails
        {
            public DateTime commitDate;

            public CommitDetails(DateTime _commitDate)
            {
                commitDate = _commitDate;
            }
        }


        /// <summary>
        /// Returns the last year's worth of commits from the Unisure application master branch
        /// </summary>
        /// <returns> A list of strings containing a years worth of commit ids </returns>
        public static async Task<Dictionary<string, CommitDetails>> GetCommitsAsync()
        {
            int currentStartIndex = 0;

            try
            {
                response = await httpClient.GetAsync($"commits?start={currentStartIndex}");
            }
            catch ( Exception e )
            {
                throw new Exception($"Opps, something went wrong! Details: {e.GetType()} : {e.Message}");
            }

            if (response.IsSuccessStatusCode)
            {
                // Magic
                // https://www.c-sharpcorner.com/article/json-serialization-and-deserialization-in-c-sharp/
                var allCommits = JsonConvert.DeserializeObject<Commits>(
                    await response.Content.ReadAsStringAsync());

                // TODO: Can we clean these date conversions up?
                // This gets us a UNIX style timestamp for now
                var today = (long)DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds;
                // This gets us UNIX timestamp representing a year
                var ayear = today - (long)DateTime.UtcNow.Subtract(new DateTime(1971, 1, 1)).TotalSeconds;
                var lastyear = (today - ayear) * 1000;
                
                // Check the authortimestamp of the first item on each page of results and only continue if the date is more recent than one year ago.
                while ((long)allCommits.values[0].authorTimestamp >= lastyear)
                {
                    if (allCommits.values != null)
                    {
                        // get all the commit ids on one page using foreach loop.
                        foreach (var item in allCommits.values)
                        {
                            DateTime convertedUnixTimeStamp = DateTime.UnixEpoch.AddMilliseconds(Convert.ToInt64(item.committerTimestamp));
                            commitIds.Add(item.displayId, new CommitDetails(convertedUnixTimeStamp));
                        }
                    }

                    currentStartIndex = allCommits.nextPageStart;
                    response = await httpClient.GetAsync($"commits?start={currentStartIndex}");

                    // set allCommits variable to the next page of results so the while loop can check the first entry and decide whether to continue.
                    allCommits = JsonConvert.DeserializeObject<Commits>(
                    await response.Content.ReadAsStringAsync());
                }

            }
            return commitIds;
        }

        /// <summary>
        /// Get the files changed under a commit id
        /// </summary>
        /// <param name="commitIds"> The list of commit ids to check. </param>
        /// <returns> A dict where the key is the file name and the key is the number of times it's been changed</returns>
        public static async Task<List<Tuple<string, string, DateTime>>> GetFileChangesAsync(Dictionary<string, CommitDetails> commitIds) // TODO: maybe add a switch param that toggles if we want the overview or all the data, or both
        {
            if (commitIds.Count > 0)
            {
                foreach (var commit in commitIds)
                {
                    try
                    {
                        response = await httpClient.GetAsync($"commits/{commit.Key}/diff");
                    }
                    catch ( Exception e )
                    {
                        throw new Exception($"Opps, something went wrong! Details: {e.GetType()} : {e.Message}");
                    }

                    if (response.IsSuccessStatusCode)
                    {
                        // More Magic
                        var allDiffs = JsonConvert.DeserializeObject<Diffs>(
                            await response.Content.ReadAsStringAsync());

                        if (allDiffs.diffs.Count > 0)
                        {
                            // export every commit to a file with the commit date
                            
                            // New files will be missing the source value, deleted files will be missing the destination value so we need to check
                            foreach (Diff diff in allDiffs.diffs)
                            {
                                string fileLocation;
                                if (diff.source != null)
                                {
                                    fileLocation = diff.source.toString;
                                }
                                else if (diff.destination != null)
                                {
                                    fileLocation = diff.destination.toString;
                                }
                                else
                                {
                                    fileLocation = "not found";
                                }
                                
                                allCommitData.Add(new Tuple<string, string, DateTime>(commit.Key, fileLocation, commit.Value.commitDate));
                            }

                            // Builds a dict with our paths and commit counts
                            //foreach (var diff in allDiffs.diffs)
                            //{
                            //    if (diff.source != null && diff.source.toString != string.Empty)
                            //    {
                            //        if (countOfTimesFileChanged.ContainsKey(diff.source.toString))
                            //        {
                            //            countOfTimesFileChanged[diff.source.toString].numberOfTimesChanged ++;
                            //            countOfTimesFileChanged[diff.source.toString].commitDates.Add(commit.Value.commitDate);
                            //        }
                            //        else
                            //        {
                            //            countOfTimesFileChanged.Add(diff.source.toString, 
                            //                                        new FileDetails() 
                            //                                        { 
                            //                                            numberOfTimesChanged = 1,
                            //                                            commitDates = new List<string>() { commit.Value.commitDate}
                            //                                        }) ;
                            //        }
                            //    }
                            //}
                        }
                    }
                }
            }
            return allCommitData;
        }
    }
}