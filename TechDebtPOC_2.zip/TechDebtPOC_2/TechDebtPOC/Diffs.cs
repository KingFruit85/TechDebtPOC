﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace TechDebtPOC
{
    public class Diffs
    {
        public object fromHash { get; set; }
        public string toHash { get; set; }
        public int contextLines { get; set; }
        public string whitespace { get; set; }
        public List<Diff> diffs { get; set; }
        public bool truncated { get; set; }
    }

    public class Self
    {
        public string href { get; set; }
    }

    public class Links
    {
        public List<Self> self { get; set; }
    }

    public class Author
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public int id { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string slug { get; set; }
        public string type { get; set; }
        public Links links { get; set; }
    }

    public class Committer
    {
        public string name { get; set; }
        public string emailAddress { get; set; }
        public int id { get; set; }
        public string displayName { get; set; }
        public bool active { get; set; }
        public string slug { get; set; }
        public string type { get; set; }
        public Links links { get; set; }
    }

    public class Parent
    {
        public string id { get; set; }
        public string displayId { get; set; }
    }

    public class Properties
    {
        [JsonProperty("jira-key")]
        public List<string> JiraKey { get; set; }
    }

    public class Source
    {
        public List<string> components { get; set; }
        public string parent { get; set; }
        public string name { get; set; }
        public string extension { get; set; }
        public string toString { get; set; }
    }

    public class Destination
    {
        public List<string> components { get; set; }
        public string parent { get; set; }
        public string name { get; set; }
        public string extension { get; set; }
        public string toString { get; set; }
    }

    public class Line
    {
        public int source { get; set; }
        public int destination { get; set; }
        public string line { get; set; }
        public bool truncated { get; set; }
    }

    public class Segment
    {
        public string type { get; set; }
        public List<Line> lines { get; set; }
        public bool truncated { get; set; }
    }

    public class Hunk
    {
        public string context { get; set; }
        public int sourceLine { get; set; }
        public int sourceSpan { get; set; }
        public int destinationLine { get; set; }
        public int destinationSpan { get; set; }
        public List<Segment> segments { get; set; }
        public bool truncated { get; set; }
    }

    public class Diff
    {
        public Source source { get; set; }
        public Destination destination { get; set; }
        public List<Hunk> hunks { get; set; }
        public bool truncated { get; set; }
    }
}