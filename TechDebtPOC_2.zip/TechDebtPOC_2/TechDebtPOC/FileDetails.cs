﻿using System.Collections.Generic;

namespace TechDebtPOC
{
    public class FileDetails
    {
        public int numberOfTimesChanged;
        public List<string> commitDates;

        public FileDetails()
        {
            numberOfTimesChanged = 0;
            commitDates = new List<string>();
        }
    }
}
